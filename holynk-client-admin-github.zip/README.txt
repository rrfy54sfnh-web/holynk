HOLYNK V1.4 — SEPARATION CLIENT / ADMIN

Déployer dans la racine du dépôt GitHub Pages holynk :
- index.html : interface publique Client
- admin/index.html : interface de gestion Admin

Adresses :
https://rrfy54sfnh-web.github.io/holynk/
https://rrfy54sfnh-web.github.io/holynk/admin/

Les deux utilisent la fonction Supabase existante « listings ». Aucun secret Supabase n’est inclus dans ces pages.
Le code courtier partagé est encore un système MVP, non une véritable authentification individuelle.
Les demandes de visite restent locales / WhatsApp ; non synchronisées dans Supabase.
Ne pas effacer index-sauvegarde.html dans GitHub.
